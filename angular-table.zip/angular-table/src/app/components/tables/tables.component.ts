import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {ModalDismissReasons, NgbModal} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-tables',
  templateUrl: './tables.component.html',
  styleUrls: ['./tables.component.css']
})
export class TablesComponent implements OnInit {

  result: any;
  resultUsers: any;
  closeResult: string;
  page = 1;
  status: string;
  completed: boolean;
  selectedValue: string;

  constructor(private http: HttpClient, private modalService: NgbModal) { }

  // tslint:disable-next-line:typedef
  ngOnInit() {
    this.http.get(`https://jsonplaceholder.typicode.com/todos`).subscribe(
      (response: Response) => {
        console.log(response);
        this.result = response;
      }
    );
    this.http.get(`https://jsonplaceholder.typicode.com/users`).subscribe(
      (response: Response) => {
        console.log(response);
        this.resultUsers = response;
      }
    );
  }
  // tslint:disable-next-line:typedef
  open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  // tslint:disable-next-line:typedef
  onClickDelete(i: number) {
    this.http.post(`https://jsonplaceholder.typicode.com/todos/:id`, i).subscribe(
      () => this.status = 'Delete successful');
    console.log(this.status);
  }
  // tslint:disable-next-line:typedef
  onNextPage() {
    this.page = this.page + 1;
  }
  // tslint:disable-next-line:typedef
  onNextNextPage() {
    this.page = this.page + 2;
  }
  // tslint:disable-next-line:typedef
  onPrevPage() {
    this.page = this.page - 1;
  }

  // tslint:disable-next-line:typedef
  onClickRadio(event: any) {
    this.selectedValue = event.target.value;
    console.log(this.selectedValue);
  }

  // tslint:disable-next-line:typedef
  onClickSave() {
    this.http.patch(`https://jsonplaceholder.typicode.com/todos/:id`, this.selectedValue).subscribe(
      () => this.completed = true);
    console.log(this.completed);
  }
}
